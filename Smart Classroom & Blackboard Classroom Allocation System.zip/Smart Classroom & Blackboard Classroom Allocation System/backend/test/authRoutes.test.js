const assert = require("node:assert/strict");
const bcrypt = require("bcryptjs");
const express = require("express");
const session = require("express-session");
const test = require("node:test");

const { createAuthRouter, requireRole } = require("../src/routes/authRoutes");

function createUserModel() {
  const users = [];
  let nextId = 1;
  return {
    users,
    async findOne(query) {
      return users.find((user) => user.email === query.email) || null;
    },
    async create(data) {
      const user = {
        ...data,
        _id: String(nextId++),
        createdAt: new Date(),
        async save() {},
      };
      users.push(user);
      return user;
    },
    findById(id) {
      return {
        lean: async () => users.find((user) => String(user._id) === String(id)) || null,
      };
    },
  };
}

test("student signup hashes passwords and cannot assign a privileged role", async (t) => {
  const UserModel = createUserModel();
  const app = express();
  app.use(express.json());
  app.use(session({
    secret: "test-auth-session-secret",
    resave: false,
    saveUninitialized: false,
  }));
  app.use("/api/auth", createAuthRouter({ UserModel }));
  app.get("/api/admin-only", requireRole("ADMIN"), (req, res) => res.json({ ok: true }));
  app.get("/api/reviewer-only", requireRole("ADMIN", "COORDINATOR"), (req, res) => res.json({ ok: true }));
  const server = app.listen(0, "127.0.0.1");
  await new Promise((resolve) => server.once("listening", resolve));
  t.after(() => new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  }));
  const baseUrl = `http://127.0.0.1:${server.address().port}`;

  const weakResponse = await fetch(`${baseUrl}/api/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name: "Demo Student", email: "student@example.edu", password: "short" }),
  });
  assert.equal(weakResponse.status, 400);

  const signupResponse = await fetch(`${baseUrl}/api/auth/signup`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      name: "Demo Student",
      email: "student@example.edu",
      password: "valid-demo-password",
      role: "ADMIN",
    }),
  });
  const signupPayload = await signupResponse.json();
  assert.equal(signupResponse.status, 201);
  assert.equal(signupPayload.user.role, "STUDENT");
  assert.equal(UserModel.users[0].role, "STUDENT");
  assert.notEqual(UserModel.users[0].passwordHash, "valid-demo-password");
  assert.equal(await bcrypt.compare("valid-demo-password", UserModel.users[0].passwordHash), true);
  UserModel.users.push(
    {
      _id: "coordinator-id",
      name: "Demo Coordinator",
      email: "coordinator@example.edu",
      passwordHash: await bcrypt.hash("coordinator-password", 4),
      role: "COORDINATOR",
    },
    {
      _id: "admin-id",
      name: "Demo Admin",
      email: "admin@example.edu",
      passwordHash: await bcrypt.hash("admin-password", 4),
      role: "ADMIN",
    },
  );

  const cookie = signupResponse.headers.get("set-cookie").split(";")[0];
  const sessionPayload = await fetch(`${baseUrl}/api/auth/session`, {
    headers: { cookie },
  }).then((response) => response.json());
  assert.equal(sessionPayload.authenticated, true);
  assert.equal(sessionPayload.user.email, "student@example.edu");

  const forbidden = await fetch(`${baseUrl}/api/admin-only`, { headers: { cookie } });
  assert.equal(forbidden.status, 403);
  const studentReviewForbidden = await fetch(`${baseUrl}/api/reviewer-only`, { headers: { cookie } });
  assert.equal(studentReviewForbidden.status, 403);

  const mismatch = await fetch(`${baseUrl}/api/auth/login`, {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({
      email: "student@example.edu",
      password: "valid-demo-password",
      role: "COORDINATOR",
    }),
  });
  assert.equal(mismatch.status, 403);

  const coordinatorLogin = await fetch(`${baseUrl}/api/auth/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      email: "coordinator@example.edu",
      password: "coordinator-password",
      role: "COORDINATOR",
    }),
  });
  assert.equal(coordinatorLogin.status, 200);
  const coordinatorCookie = coordinatorLogin.headers.get("set-cookie").split(";")[0];
  const coordinatorCanReview = await fetch(`${baseUrl}/api/reviewer-only`, {
    headers: { cookie: coordinatorCookie },
  });
  assert.equal(coordinatorCanReview.status, 200);
  const coordinatorCannotAdminister = await fetch(`${baseUrl}/api/admin-only`, {
    headers: { cookie: coordinatorCookie },
  });
  assert.equal(coordinatorCannotAdminister.status, 403);

  const adminLogin = await fetch(`${baseUrl}/api/auth/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      email: "admin@example.edu",
      password: "admin-password",
      role: "ADMIN",
    }),
  });
  assert.equal(adminLogin.status, 200);
  const adminCookie = adminLogin.headers.get("set-cookie").split(";")[0];
  const adminAuthorized = await fetch(`${baseUrl}/api/admin-only`, {
    headers: { cookie: adminCookie },
  });
  assert.equal(adminAuthorized.status, 200);

  const logout = await fetch(`${baseUrl}/api/auth/logout`, {
    method: "POST",
    headers: { cookie },
  });
  assert.equal(logout.status, 200);
  const restoredAfterLogout = await fetch(`${baseUrl}/api/auth/session`, {
    headers: { cookie },
  }).then((response) => response.json());
  assert.equal(restoredAfterLogout.authenticated, false);
});
