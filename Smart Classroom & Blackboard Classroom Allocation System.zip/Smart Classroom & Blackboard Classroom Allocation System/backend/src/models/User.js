const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    minlength: 2,
  },
  email: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    unique: true,
    match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  },
  passwordHash: {
    type: String,
    required: true,
    minlength: 60,
  },
  role: {
    type: String,
    required: true,
    enum: ["STUDENT", "ADMIN", "COORDINATOR", "HOD", "DIRECTOR"],
    default: "STUDENT",
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("User", userSchema);
