function planEventAllocation({
  eventType,
  participantCount,
  candidateRooms,
}) {
  if (!["EXAM", "PLACEMENT"].includes(eventType)) {
    throw new TypeError("eventType must be EXAM or PLACEMENT.");
  }
  if (!Number.isInteger(participantCount) || participantCount < 1) {
    throw new TypeError("participantCount must be a positive integer.");
  }
  if (!Array.isArray(candidateRooms)) {
    throw new TypeError("candidateRooms must be an array.");
  }

  const verifiedAvailableRooms = candidateRooms
    .filter(
      (room) =>
        room.availabilityStatus === "AVAILABLE" &&
        Number.isInteger(room.capacity) &&
        room.capacity > 0 &&
        room.capacityStatus === "CONFIRMED",
    )
    .sort((first, second) => second.capacity - first.capacity);
  const unverifiedRoomCount = candidateRooms.filter(
    (room) => room.availabilityStatus === "CANNOT_VERIFY" ||
      room.capacityStatus !== "CONFIRMED",
  ).length;
  const selectedRooms = [];
  let plannedCapacity = 0;

  for (const room of verifiedAvailableRooms) {
    selectedRooms.push(room);
    plannedCapacity += room.capacity;
    if (plannedCapacity >= participantCount) {
      break;
    }
  }

  if (plannedCapacity >= participantCount) {
    return {
      eventType,
      status: "PREVIEW_READY",
      allocationCreated: false,
      participantCount,
      plannedCapacity,
      rooms: selectedRooms.map((room) => ({
        roomNumber: room.roomNumber,
        block: room.block,
        capacity: room.capacity,
      })),
      message:
        "A capacity-sufficient preview was calculated. No rooms have been reserved or allotted.",
    };
  }

  if (unverifiedRoomCount > 0) {
    return {
      eventType,
      status: "CANNOT_VERIFY",
      allocationCreated: false,
      participantCount,
      plannedCapacity,
      rooms: [],
      unverifiedRoomCount,
      message:
        "No safe allocation preview is possible because one or more candidate rooms have unverified availability or capacity.",
    };
  }

  return {
    eventType,
    status: "INSUFFICIENT_CAPACITY",
    allocationCreated: false,
    participantCount,
    plannedCapacity,
    rooms: [],
    message:
      "Confirmed available room capacity does not meet the requested participant count.",
  };
}

module.exports = { planEventAllocation };
